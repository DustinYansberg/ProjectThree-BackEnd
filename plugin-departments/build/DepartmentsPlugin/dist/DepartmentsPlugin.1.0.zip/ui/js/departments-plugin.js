function changeText() {
    document.getElementById("test").innerHTML = "Text has been changed.";
}

function createDepartment() {
    console.log("Creating department with name " + document.getElementById("dept_name").innerHTML);
}